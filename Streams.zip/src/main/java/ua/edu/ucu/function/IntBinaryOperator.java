package ua.edu.ucu.function;

public interface IntBinaryOperator {
    int apply(int left, int right);
}
