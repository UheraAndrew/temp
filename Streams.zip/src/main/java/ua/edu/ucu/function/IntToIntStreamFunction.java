package ua.edu.ucu.function;

import ua.edu.ucu.stream.IntStream;

public interface IntToIntStreamFunction {
     IntStream applyAsIntStream(int value);
}
