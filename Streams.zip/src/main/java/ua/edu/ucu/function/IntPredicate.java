package ua.edu.ucu.function;

public interface IntPredicate {
    boolean test(int value);
}
