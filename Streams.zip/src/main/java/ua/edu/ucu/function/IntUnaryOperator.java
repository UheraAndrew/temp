package ua.edu.ucu.function;

public interface IntUnaryOperator {
    int apply(int operand);
}
